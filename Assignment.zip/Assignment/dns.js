/* 
Name of module: dns

Description: this module provides a set of functions 
that allow Node.js applications to perform DNS operations 
like resolving hostnames to IP addresses and vice versa.
It has several properties and methods e.g resolve(), lookup(), getServers() etc.

Example: */
const dns = require('dns');

dns.resolve('www.mywebsite.com', (err, addresses) => {
  if (err) throw err;

  console.log('IP addresses for www.mywebsite.com:', addresses);
});


/*Here, the 'resolve' method is used to perform a DNS lookup for the hostname www.mywebsite.com. 
The addresses parameter in the callback function contains an array of IP addresses that correspond
 to the hostname.*/