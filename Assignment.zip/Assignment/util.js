/* 
Name of module: util

Description: this module provides a set of utility functions that are commonly used in Node.js applications. 
The module contains various methods that help in debugging, inspecting objects, and handling errors such as .
debuglog(), inspect(), format() etc.

Example: */

const util = require('util');
const name = 'Oluwadamilare';
const age = 18;

const message = util.format('%s is %d years old', name, age);
console.log(message);


/*This example formats a string using placeholders.*/