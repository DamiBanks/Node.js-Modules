/* 
Name of module: v8

Description: this module provides access to the V8 engine's APIs for memory management, 
profiling, and other low-level functionality. 

Example: */

const v8 = require('v8');

console.log(v8.getHeapStatistics());


/*This example logs the total heap size and the amount of memory used.*/