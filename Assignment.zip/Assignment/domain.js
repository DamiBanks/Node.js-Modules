/* 
Name of module: domain

Description: this module allows you to handle errors that 
occur in multiple asynchronous operations and associated 
callbacks in a single place, rather than propagating the 
error up the callback chain.

Example: */
const domain = require('domain').create();

domain.on('error', (err) => {
  console.log('Error:', err);
});

domain.enter();

fs.readFile('some-file.txt', (err, data) => {
  if (err) {
    domain.emit('error', err);
    return;
  }

  console.log(data);
});

domain.exit();



/*Here, a new domain object is created and an event handler 
for the 'error' event is registered. We then enter the domain and perform 
an I/O operation. If the I/O operation fails, we emit 
the 'error' event and handle the error in the event handler. 
Finally, we exit the domain..*/