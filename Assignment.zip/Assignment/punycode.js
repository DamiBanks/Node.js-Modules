/* 
Name of module: punycode

Description: this module provides utilities for encoding and decoding Unicode domain names to 
ASCII-compatible encoding known as Punycode. This is useful when dealing with internationalized 
domain names (IDNs) that contain non-ASCII characters.

Example: */

const punycode = require('punycode');

const domainName = 'ロシア.com';
const asciiName = punycode.toASCII(domainName);

console.log(asciiName);


/*This example converts non-ASCII domain names to their ASCII equivalent.*/