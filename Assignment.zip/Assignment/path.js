/* 
Name of module: path

Description: this module provides a set of methods for working with 
file paths. It provides an easy way to manipulate file paths 
regardless of the operating system being used.

Example: */

const path = require('path');

const absolutePath = path.resolve('users', 'administrator', 'documents', '..', 'downloads');
console.log(absolutePath); 


/*This example resolves a sequence of paths or path segments into an absolute path.*/