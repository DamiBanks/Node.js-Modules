/* 
Name of module: stream

Description: this module provides an API for implementing streaming data flows. 
It allows for the manipulation of large amounts of data in a memory-efficient and 
performant way, as it processes data in small chunks, called "streams". 
Streams can be read, written to, and piped to other streams, enabling flexible and 
powerful data processing pipelines.

Example: */

const fs = require('fs');

const readStream = fs.createReadStream('1.txt');
const writeStream = fs.createWriteStream('2.txt');

readStream.pipe(writeStream);



/*This example reads data from a file(1.txt) using a 'ReadStream' and writes it to another file(2.txt) 
using a 'WriteStream'.*/