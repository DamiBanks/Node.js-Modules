/* 
Name of module: http

Description: this module provides the ability to create an HTTP server and make 
HTTP requests. The module provides a set of functions and classes that allow 
developers to work with the HTTP protocol. 

Example: */
const http = require('http');

http.get('http://www.google.com/', (res) => {
  console.log(`Got response: ${res.statusCode}`);
  res.on('data', (chunk) => {
    console.log(`Received ${chunk.length} bytes of data.`);
  });
}).on('error', (e) => {
  console.error(`Got error: ${e.message}`);
});

/*Here, an HTTP GET request is made to the Google homepage.*/