/* 
Name of module: crypto

Description: this module provides cryptographic functionality 
that includes hashing, encryption, and decryption.
It has several properties and methods e.g createHash() etc.

Example: */
const crypto = require('crypto');

const hash = crypto.createHash('sha256');
hash.update('Hello, World!');
const result = hash.digest('hex');

console.log(result);


/*Here, the SHA256 algorithm is used to generate a hash of a string.*/