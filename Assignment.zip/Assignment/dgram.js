/* 
Name of module: dgram (Datagram)

Description: this module is used to create UDP (User Datagram Protocol) 
sockets, which are used for sending and receiving datagrams. It
provides a simple and efficient way to implement real-time 
communication between networked devices.

Example: */
const dgram = require('dgram');

const server = dgram.createSocket('udp4');

server.on('error', (err) => {
  console.log(`Server error:\n${err.stack}`);
  server.close();
});

server.on('message', (msg, rinfo) => {
  console.log(`Server got: ${msg} from ${rinfo.address}:${rinfo.port}`);
});

server.on('listening', () => {
  const address = server.address();
  console.log(`Server listening ${address.address}:${address.port}`);
});

server.bind(3000);

/*Here, a UDP server that listens on port 3000 is created. 
When a message is received, it logs the message and 
the address and port of the sender.*/