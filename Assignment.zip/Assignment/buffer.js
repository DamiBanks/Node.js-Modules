/* 
Name of module: buffer

Description: this module provides a way of handling streams of binary data.
It is a global object in Node.js, and it is not necessary to import it 
using the "require" keyword. It has several properties and methods 
e.g alloc(), concat() etc.

Example: */
var buf = Buffer.alloc(15);

/*Here, an empty Buffer of the length 15 is created.*/