/* 
Name of module: readline

Description: this module provides an interface for reading data from 
a Readable stream (such as the terminal input) on a line-by-line basis. 
It allows developers to create interactive command-line interfaces (CLIs) 
and other similar applications.

Example: */

const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('What is your name? ', (answer) => {
  console.log(`Hello, ${answer}!`);
  
  rl.close();
});


/*This example creates a 'readline' interface that reads input from the terminal 
and echoes it back to the user until the input is the word 'exit'.*/