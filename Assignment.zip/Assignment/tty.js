/* 
Name of module: tty (teletype)

Description: this module provides a way to interact with the terminal or console. 
It provides functions for creating and interacting with TTY (teletype) streams, 
which are text input and output streams typically used for interactive command-line interfaces.

Example: */

const tty = require('tty');
const fs = require('fs');

if (tty.isatty(fs.createReadStream('/node/output'))) {
  console.log('Correct.');
} else {
  console.log('Wrong.');
}


/*This example checks if a stream created from the '/node/output' file is a TTY and prints a message accordingly.*/