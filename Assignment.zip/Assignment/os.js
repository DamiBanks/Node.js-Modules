/* 
Name of module: os

Description: this module provides an interface to some of the underlying 
operating system functionality such as retrieving information about the 
computer's CPU, memory, network interfaces, and file system.

Example: */

const os = require('os');

console.log(os.cpus().length);


/*This example prints the number of CPU cores on the system.*/