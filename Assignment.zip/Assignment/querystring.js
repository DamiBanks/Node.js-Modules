/* 
Name of module: querystring

Description: this module provides utilities for working with query strings. 
A query string is a part of a URL that contains data that is passed to the 
server as key-value pairs. The querystring module can be used to parse and 
stringify query strings. 

Example: */

const querystring = require('querystring');

const obj = { name: 'Oluwadamilare', age: 18, city: 'Lagos' };
const str = querystring.stringify(obj);

console.log(str);

/*This example creates an object and stringifies it into a query string.*/