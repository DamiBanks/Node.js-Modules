/* 
Name of module: assert

Description: this module when used, provides a set of assertion tests. 
It can be used to check the value of any expression, and it can be used to 
throw an error if the expression does not evaluate to the expected value.

Example: */
const assert = require('assert');
function add(a, b) {
  return a + b;
}
assert.strictEqual(add(1, 1), 2);

/*Here, the assert.strictEqual() method checks whether the result of 
calling add(1, 1) is equal to 2. If the assertion fails, 
an AssertionError will be thrown.*/