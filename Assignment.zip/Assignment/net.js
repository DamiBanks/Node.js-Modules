/* 
Name of module: net

Description: this module provides an asynchronous network API for creating servers 
and clients. It is used for creating TCP and UNIX socket servers and clients.

Example: */

const net = require('net');

const client = net.createConnection({ port: 5500 }, () => {
  console.log('Connected to server');

  client.write('Hello, server!');
});

client.on('data', (data) => {
  console.log('Received data:', data.toString());
});

client.on('end', () => {
  console.log('Disconnected from server');
});

/*This example creates a TCP client that connects to a server on 
port 5500 and sends a message.*/