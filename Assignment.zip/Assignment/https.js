/* 
Name of module: https

Description: this module provides functions for making secure HTTPS requests and creating HTTPS servers. 
It supports SSL and TLS encryption, supports HTTP/1.1 and HTTP/2 protocols.

Example: */
const https = require('https');
const fs = require('fs');

const options = {
  key: fs.readFileSync('server.key'),
  cert: fs.readFileSync('server.crt')
};

https.createServer(options, (req, res) => {
  res.writeHead(200);
  res.end('Hello there!');
}).listen(443);


/*This example creates an HTTPS server using the createServer method. 
It requires a key and cert option that specifies the SSL/TLS certificate 
and private key to use for secure communication. It responds to requests 
with a simple "Hello there!" message.*/