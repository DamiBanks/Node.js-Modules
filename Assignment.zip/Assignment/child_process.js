/* 
Name of module: child_process

Description: this module provides a way to create and interact with child processes in Node.js. 
A child process is a separate process that is created by the parent process. Child processes can be 
used to perform tasks that are not possible or efficient to perform in the parent process.

Example: */
const child = spawn('child', ['-l']);

/*Here, the spawn() method is used to spawn a new child process. The spawn() method takes 
two arguments: the name of the executable file to run and an array of arguments to pass 
to the executable file.*/