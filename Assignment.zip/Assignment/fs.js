/* 
Name of module: fs

Description: this module provides an API for interacting with the file system. 
It allows you to perform operations on the file system such as reading, writing, 
updating, and deleting files and directories.

Example: */
const fs = require('fs');

fs.readFile('events.js', 'utf8', (err, data) => {
  if (err) throw err;
  console.log(data);
});

/*Here, the module is used to read the contents of a file named 'events.js' 
and logs it to the console.*/