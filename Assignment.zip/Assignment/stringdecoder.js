/* 
Name of module: string decoder

Description: this module provides an API for decoding Buffer objects into strings. It is particularly 
useful for working with non-UTF-8 encoded text, as it provides a way to decode multi-byte characters.

Example: */

const { StringDecoder } = require('string_decoder');

const decoder = new StringDecoder('utf8');
const buffer = Buffer.from('3bh48hbjkz5', 'hex');

console.log(decoder.write(buffer)); 

/*This example the string_decoder module is used to decode a Buffer object.*/