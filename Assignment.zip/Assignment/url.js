/* 
Name of module: url

Description: this module provides a set of utilities for parsing and formatting URLs. 
It allows you to parse a URL into its various components (protocol, hostname, port, path, etc.), 
modify those components, and then format them back into a URL string.

Example: */

const url = require('url');

const myUrl = 'https://www.mywebsite.com:5500/node/js/url?query=string#fragment';
const parsedUrl = url.parse(myUrl, true);

console.log(parsedUrl.protocol); 
console.log(parsedUrl.hostname); 
console.log(parsedUrl.port); 
console.log(parsedUrl.pathname); 
console.log(parsedUrl.query); 
console.log(parsedUrl.hash); 

/*This example parses a URL into its various components.*/