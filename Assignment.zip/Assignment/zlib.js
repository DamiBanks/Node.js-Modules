/* 
Name of module: zlib

Description: this module provides acompression and decompression functionalities using the zlib compression algorithm. 
It can be used to compress and decompress files, streams, and buffers.

Example: */

const zlib = require('zlib');

const compressed = Buffer.from('eJzLSM3JyVcozy/KSQEAGQ==', 'base64');

zlib.inflate(compressed, (err, decompressed) => {
  if (err) throw err;

  console.log(decompressed.toString());
});



/*This example creates a buffer from a Base64 string that represents compressed data. It then decompresses the buffer using 
the inflate() method from the 'zlib' module, which decompresses the data using the zlib.*/