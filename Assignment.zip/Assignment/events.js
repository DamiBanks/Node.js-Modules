/* 
Name of module: events

Description: this module provides an implementation of the EventEmitter class, 
which allows objects to emit named events and attach listeners to those events. 

Example: */
const EventEmitter = require('events');

const myEmitter = new EventEmitter();

myEmitter.on('greeting', (name) => {
  console.log(`Hello, ${name}!`);
});

myEmitter.emit('greeting', 'Oluwadamilare');


/*Here, an EventEmitter object is created and an event listener is attached to it.*/