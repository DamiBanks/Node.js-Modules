/* 
Name of module: cluster

Description: this module provides a way of creating child processes that runs simultaneously and 
share the same server port. It has several properties and methods e.g fork(), disconnect() etc.

Example: */
const cluster = require('cluster');

/*Here, is how to include the cluster module in your application.*/