/* 
Name of module: timers

Description: this module provides functions for scheduling and executing callbacks at specific times or intervals. 
Its includes methods such as setTimeout(), setInterval(), setImmediate(), and clearTimeout(), which allow developers
 to control the timing of their code execution.

Example: */

setTimeout(() => {
  console.log('You are late!');
}, 1000);

/*This example logs a message to the console after a 1-second delay.*/